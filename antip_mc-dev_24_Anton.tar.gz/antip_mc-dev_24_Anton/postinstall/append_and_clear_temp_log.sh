#!/bin/bash

MINION_FILE=$1
MINION_ID=$2

# Определяем файл на мастере в зависимости от пути измененного файла
if [ "$MINION_FILE" == "/opt/AntiP_hiscan/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-Hiscan.log"
elif [ "$MINION_FILE" == "/opt/AntiP_scraper/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-Scrapper.log"
elif [ "$MINION_FILE" == "/opt/AntiP_semantic/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-Semantic.log"
elif [ "$MINION_FILE" == "/opt/AntiP_imgscanner/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-Imgscanner.log"
elif [ "$MINION_FILE" == "/opt/AntiP_dmz/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-DMZ.log"
elif [ "$MINION_FILE" == "/opt/AntiP_dmz_api/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-DMZAPI.log"
elif [ "$MINION_FILE" == "/opt/AntiP_core/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-Core.log"
elif [ "$MINION_FILE" == "/opt/AntiP_mpd/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-MPD.log"
elif [ "$MINION_FILE" == "/opt/AntiP_tasker/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-Tasker.log"
elif [ "$MINION_FILE" == "/opt/AntiP_tasker_dmz/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-TaskerDMZ.log"
elif [ "$MINION_FILE" == "/opt/AntiP_connector_kc/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-ConnectorKC.log"
elif [ "$MINION_FILE" == "/opt/AntiP_incubator/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-Incubator.log"
elif [ "$MINION_FILE" == "/opt/AntiP_lko/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-LKO.log"
elif [ "$MINION_FILE" == "/opt/AntiP_lku/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-LKU.log"
elif [ "$MINION_FILE" == "/opt/AntiP_scim/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-SCIM.log"
elif [ "$MINION_FILE" == "/opt/AntiP_api/logs/temp_system.log" ]; then
	MASTER_FILE="/opt/AntiP_mc/logs/minions/ANTIP-API.log"
else
	echo "Unknown MINION_FILE: $MINION_FILE"
	exit 1
fi

# Читаем содержимое файла на миньоне
SALT_MINION_CONTENT=$(salt "$MINION_ID" cmd.run "cat ${MINION_FILE}")

# Если файл на миньоне не пустой, добавляем его содержимое в файл на мастере
if [ $(echo "$SALT_MINION_CONTENT" | wc -l) -gt 1 ]; then
	CONTENT=$(salt "$MINION_ID" cmd.run "cat ${MINION_FILE}; > ${MINION_FILE}")
	echo "$CONTENT" | tail -n +2 | cut -c 5- >> ${MASTER_FILE}
fi
