let updateInterval;

// Обновление состояния кнопок управления сервисами
function updateButtonState(component, state) {
  const start_button = document.getElementById(`start_button_${component}`);
  const stop_button = document.getElementById(`stop_button_${component}`);
  const restart_button = document.getElementById(`restart_button_${component}`);
  if (state === 'active') {
    start_button.setAttribute('disabled', 'disabled');
    stop_button.removeAttribute('disabled');
    restart_button.removeAttribute('disabled');
  } else if (state === 'inactive') {
    stop_button.setAttribute('disabled', 'disabled');
    start_button.removeAttribute('disabled');
    restart_button.removeAttribute('disabled');
  } else if (state === 'offline') {
    stop_button.setAttribute('disabled', 'disabled');
    start_button.setAttribute('disabled', 'disabled');
    restart_button.setAttribute('disabled', 'disabled');
  }
}

// Функция для обновления данных на странице
function updateData() {
  fetch('/home_data')
    .then(response => response.json())
    .then(data => {
      // Обновление статусов тестов сервисов
      Object.keys(data).forEach(component => {
        const homeData = data[component];
        if (homeData) {
          Object.keys(homeData).forEach(test => {
            const button_status = homeData['component_service'];
            updateButtonState(component, button_status);
            const status = homeData[test];
            const elementId = `${component}_${test}_test`;
            const element = document.getElementById(elementId);
            if (element) {
              element.classList.remove('bg-success', 'bg-danger', 'bg-gray-500', 'text-white', 'text-black');
              element.classList.add('rounded-1', 'mx-0', 'px-1', 'text-white');

              if (status === 'active') {
                element.textContent = 'Онлайн';
                element.classList.add('bg-success');
              } else if (status === 'inactive') {
                element.textContent = 'Внимание';
                element.classList.add('bg-danger');
              } else if (status === 'offline') {
                element.textContent = 'Ошибка проверки';
                element.classList.add('bg-gray-500');
              }
            }
          });
        }
      });
    })
    .catch(error => console.error('Ошибка при получении данных компонента:', error));

  // Обновление времени
  const timeElement = document.getElementById(`update_time`);
  if (timeElement) {
    const now = new Date().toLocaleTimeString();
    timeElement.innerHTML = `<span class="fas fa-clock"></span><span class="ps-2">Обновлено: ${now}</span>`;
  }
}

// Функции для отправки запросов на сервер
async function startServices(component) {
  try {
    const response = await fetch(`/start_services/${component}`);
    if (!response.ok) {
      throw new Error('Ошибка HTTP: ' + response.status);
    }
  } catch (error) {
    console.error('Ошибка при запуске сервисов:', error);
  }
}

async function stopServices(component) {
  try {
    const response = await fetch(`/stop_services/${component}`);
    if (!response.ok) {
      throw new Error('Ошибка HTTP: ' + response.status);
    }
  } catch (error) {
    console.error('Ошибка при остановке сервисов:', error);
  }
}

async function restartServices(component) {
  try {
    const response = await fetch(`/restart_services/${component}`);
    if (!response.ok) {
      throw new Error('Ошибка HTTP: ' + response.status);
    }
  } catch (error) {
    console.error('Ошибка при перезапуске сервисов:', error);
  }
}

// Функция для обработки состояния кнопок и добавления/удаления спиннера
function handleButtonClick(button, component, actionFunction, isRestart = false) {
  const icon = button.querySelector('span');
  const originalClass = icon.className;
  icon.className = 'fas fa-spinner fa-pulse';

  actionFunction(component).finally(() => {
    if (!isRestart) {
      const checkIfDisabled = setInterval(() => {
        if (button.hasAttribute('disabled')) {
          icon.className = originalClass;
          clearInterval(checkIfDisabled);
        }
      }, 100);
    }
  });

  if (isRestart) {
    setTimeout(() => {
      icon.className = originalClass;
    }, 20000);
  }
}

// Обработчики событий для кнопок
document.addEventListener('DOMContentLoaded', () => {
  // Добавляем обработчики событий для всех кнопок
  document.querySelectorAll('button[id^="start_button_"]').forEach(button => {
    button.addEventListener('click', () => {
      const component = button.id.split('_')[2];
      notyf.success(`Сервисы компонента ${component} запущены`);
      handleButtonClick(button, component, startServices);
    });
  });

  document.querySelectorAll('button[id^="stop_button_"]').forEach(button => {
    button.addEventListener('click', () => {
      const component = button.id.split('_')[2];
      notyf.success(`Сервисы компонента ${component} остановлены`);
      handleButtonClick(button, component, stopServices);
    });
  });

  document.querySelectorAll('button[id^="restart_button_"]').forEach(button => {
    button.addEventListener('click', () => {
      const component = button.id.split('_')[2];
      notyf.success(`Сервисы компонента ${component} перезапущены`);
      handleButtonClick(button, component, restartServices, true);
    });
  });

  // Первоначальное обновление при загрузке страницы
  updateData();
  updateInterval = setInterval(updateData, 10000);
});
