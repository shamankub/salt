"use strict";
const d = document;
d.addEventListener("DOMContentLoaded", function (event) {
    // options
    const breakpoints = {
        sm: 540,
        md: 720,
        lg: 960,
        xl: 1140
    };
    // sidebar responsive
    var sidebar = document.getElementById('sidebarMenu')
    if (sidebar && d.body.clientWidth < breakpoints.lg) {
        sidebar.addEventListener('shown.bs.collapse', function () {
            document.querySelector('body').style.position = 'fixed';
        });
        sidebar.addEventListener('hidden.bs.collapse', function () {
            document.querySelector('body').style.position = 'relative';
        });
    }
    // Tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});

window.icons = {
    paginationSwift: 'fa-collapse-up',
    toggle: 'fa-toggle-on',
    columns: 'fa-columns',
    clear: 'fa-times',
    clearSearch: 'fa-times',
    filterControlSwitchHide: 'fa-filter',
    filterControlSwitchShow: 'fa-sort',
    export: 'fa-cloud-download-alt',
    fullscreen: 'fa-arrows-alt',
    paginationSwitchDown: 'fa-caret-square-down',
    paginationSwitchUp: 'fa-caret-square-up',
    refresh: 'fa-sync',
    toggleOff: 'fa-toggle-off',
    toggleOn: 'fa-toggle-on',
    detailOpen: 'fa-plus',
    detailClose: 'fa-minus'
};

const notyf = new Notyf({
    types: [
      {
        type: 'info',
        background: '#007ab3',
        icon: {
            className: 'fas fa-exclamation',
            tagName: 'span',
            color: "#ffffff"
        },
      }
    ]
  });

$(function () {
    $.scrollUp({
        animation: 'fade',
        scrollDistance: 200,
        // activeOverlay: '#00FFFF',
        scrollImg: {
            active: true,
            type: 'background'
        }
    })
});