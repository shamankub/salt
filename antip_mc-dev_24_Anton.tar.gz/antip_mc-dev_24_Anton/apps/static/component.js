$(document).ready(function () {
  // Кнопка обновления страницы
  $('button.reloadComponentPage').on('click', function () {
    notyf.success('Обновление карточки');
    if (typeof window.updateData === 'function') {
      window.updateData();
    } else {
      console.error('Функция updateData не определена');
    }
  });
});
