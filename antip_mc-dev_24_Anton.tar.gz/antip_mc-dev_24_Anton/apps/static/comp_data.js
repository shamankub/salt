let updateInterval;
let initialScroll = true;

const start_button = document.getElementById('start_button');
const stop_button = document.getElementById('stop_button');
const restart_button = document.getElementById('restart_button');

// Обновление состояния кнопок управления сервисами
function updateButtonState(state) {
    if (state === 'active') {
        start_button.setAttribute('disabled', 'disabled');
        stop_button.removeAttribute('disabled');
        restart_button.removeAttribute('disabled');
    } else if (state === 'inactive') {
        stop_button.setAttribute('disabled', 'disabled');
        start_button.removeAttribute('disabled');
        restart_button.removeAttribute('disabled');
    } else if (state === 'offline') {
        stop_button.setAttribute('disabled', 'disabled');
        start_button.setAttribute('disabled', 'disabled');
        restart_button.setAttribute('disabled', 'disabled');
    }
}

// Функция для обновления данных на странице
function updateData() {
    fetch(`/component_data/${component}`)
        .then(response => response.json())
        .then(data => {
            const componentData = data[component];
            if (componentData) {
                // Обновление тестов
                Object.keys(componentData).forEach(test => {
                    if (test !== 'sysstat_data' && test !== 'log_data') {
                        const service_status = componentData['component_service'];
                        updateButtonState(service_status);
                        const status = componentData[test];
                        const elementId = `${component}_${test}_test`;
                        const element = document.getElementById(elementId);

                        if (element) {
                            element.textContent = status;
                            element.classList.remove('bg-success', 'bg-danger', 'bg-gray-500', 'text-white', 'text-black');
                            element.classList.add('rounded-1', 'mx-0', 'px-1', 'text-white');
                            if (status === 'Онлайн') {
                                element.classList.add('bg-success');
                            } else if (status === 'Ошибка проверки') {
                                element.classList.add('bg-gray-500');
                            } else if (status === 'Внимание') {
                                element.classList.add('bg-danger');
                            }
                        }
                    }
                });

                // Обновление системных показателей
                const sysstatData = componentData['sysstat_data'];
                if (sysstatData) {
                    Object.keys(sysstatData).forEach(tag => {
                        const elementId = `${component}_${tag}`;
                        const element = document.getElementById(elementId);
                        const value = sysstatData[tag];

                        if (element && value !== undefined) {
                            element.textContent = value;
                        }
                    });
                }

                // Обновление лог-данных
                const logData = componentData['log_data'];
                const logElement = document.getElementById(`${component}_logs`);
                if (logElement && logData) {
                    logElement.innerHTML = '';
                    logData.forEach(line => {
                        const logLineElement = document.createElement('div');
                        logLineElement.textContent = line;
                        logLineElement.classList.add('text-white');
                        logElement.appendChild(logLineElement);
                    });
                    // Автопрокрутка логов к низу при загрузке страницы
                    if (initialScroll) {
                        logElement.scrollTop = logElement.scrollHeight;
                        initialScroll = false;
                    }
                }

                // Обновление времени
                const timeElement = document.getElementById(`update_time`);
                if (timeElement) {
                    const now = new Date().toLocaleTimeString();
                    timeElement.innerHTML = `<span class="fas fa-clock"></span><span class="ps-2">Обновлено: ${now}</span>`;
                }
            }
        })
        .catch(error => console.error('Ошибка при получении данных компонента:', error));
}

// Функции для отправки запросов на сервер
async function startServices(component) {
    try {
        const response = await fetch(`/start_services/${component}`);
        if (!response.ok) {
            throw new Error('Ошибка HTTP: ' + response.status);
        }
        console.log(`Сервисы компонента ${component} успешно запущены.`);
    } catch (error) {
        console.error('Ошибка при запуске сервисов:', error);
    }
}

async function stopServices(component) {
    try {
        const response = await fetch(`/stop_services/${component}`);
        if (!response.ok) {
            throw new Error('Ошибка HTTP: ' + response.status);
        }
        console.log(`Сервисы компонента ${component} успешно остановлены.`);
    } catch (error) {
        console.error('Ошибка при остановке сервисов:', error);
    }
}

async function restartServices(component) {
    try {
        const response = await fetch(`/restart_services/${component}`);
        if (!response.ok) {
            throw new Error('Ошибка HTTP: ' + response.status);
        }
        console.log(`Сервисы компонента ${component} успешно перезапущены.`);
    } catch (error) {
        console.error('Ошибка при перезапуске сервисов:', error);
    }
}

// Делаем функцию доступной глобально
window.updateData = updateData;

// Функция для обработки состояния кнопок и добавления/удаления спиннера
function handleButtonClick(button, component, actionFunction, isRestart = false) {
    const icon = button.querySelector('span');
    const originalClass = icon.className;
    icon.className = 'fas fa-spinner fa-pulse';

    actionFunction(component).finally(() => {
        // Спиннер на кнопке запуска/остановки крутится, пока с миньона не прийдёт ответ о запуске/остановке сервисов
        if (!isRestart) {
            const checkIfDisabled = setInterval(() => {
                if (button.hasAttribute('disabled')) {
                    icon.className = originalClass;
                    clearInterval(checkIfDisabled);
                }
            }, 100);
        }
    });
    // Спиннер на кнопке перезапуска крутится 20 секунд
    if (isRestart) {
        setTimeout(() => {
            icon.className = originalClass;
        }, 20000);
    }
}

// Обработчики событий для кнопок
document.getElementById('start_button').addEventListener('click', () => {
    notyf.success('Сервисы запущены');
    handleButtonClick(start_button, component, startServices);
});

document.getElementById('stop_button').addEventListener('click', () => {
    notyf.success('Сервисы остановлены');
    handleButtonClick(stop_button, component, stopServices);
});

document.getElementById('restart_button').addEventListener('click', () => {
    notyf.success('Сервисы перезапущены');
    handleButtonClick(restart_button, component, restartServices, true);
});

// Первоначальное обновление при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    updateData();
    updateInterval = setInterval(updateData, 10000);
});
