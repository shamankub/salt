# -*- encoding: utf-8 -*-
import logging
import os
from importlib import import_module

from flask import Flask
from flask_login import LoginManager
from flask_socketio import SocketIO
from concurrent_log_handler import ConcurrentRotatingFileHandler

if not os.path.exists('logs'):
    os.mkdir('logs')

# Заменяет файл после достижения 5MB, хранит 5 старых копий.
rotateHandler = ConcurrentRotatingFileHandler(
    'logs/system.log', "a", 5*1024*1024, 5, encoding='utf-8')
rotateHandler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'))
rotateHandler.setLevel(logging.DEBUG)


login_manager = LoginManager()
socketio = SocketIO()


def register_extensions(app):
    """Регистрация расширений."""
    socketio.init_app(app)
    login_manager.init_app(app)


def register_blueprints(app):
    """Регистрация модулей приложения."""
    for module_name in ("authentication", "home"):
        module = import_module(f"apps.{module_name}.routes")
        app.register_blueprint(module.blueprint)


def create_app(config):
    """Создание приложения."""
    app = Flask(__name__)
    app.config.from_object(config)
    register_extensions(app)
    register_blueprints(app)
    app.logger.addHandler(rotateHandler)
    app.logger.setLevel(logging.DEBUG)
    app.logger.info('========== AntiP MC START ==========')
    return app
