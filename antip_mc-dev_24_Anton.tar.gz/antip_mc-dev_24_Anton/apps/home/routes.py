import requests
from flask import render_template, jsonify
from urllib3.exceptions import InsecureRequestWarning
from apps.home import blueprint
from apps.home.utils import minion_services_action_command, load_component_statuses, read_yaml
from modules.tests_names_list import TESTS_NAMES, SYSSTAT_TAGS, SYSSTAT_RU
from apps.config import config
from flask_login import login_required
import salt.client


# Подавление предупреждений о незащищенном соединении
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

local = salt.client.LocalClient()


@blueprint.route("/home", methods=["GET"])
def home():
    """
    Отображает главную страницу с компонентами.

    Возвращает:
    str: HTML страница.
    """
    components = load_component_statuses()

    return render_template(
        "home/home.html",
        components=components,
        tests=TESTS_NAMES,
        components_desc=config.get("components")
    )


@blueprint.route("/home_data", methods=["GET"])
def get_home_data():
    """
    Возвращает данные о всех компонентах в формате JSON.

    Возвращает:
    Response: JSON ответ с данными о компонентах.
    """
    components_statuses = load_component_statuses()
    return jsonify(components_statuses)


@blueprint.route("/<component>", methods=["GET"])
@login_required
def component_page(component):
    """
    Страница с показателями компонента.

    Параметры:
    component (str): Имя компонента.

    Возвращает:
    str: HTML страница с данными о компоненте.
    """
    component_data = get_component_data(component)
    return render_template(
        "home/component.html",
        components=config.get("components"),
        component=component,
        tests=TESTS_NAMES,
        sysstat_tags=SYSSTAT_TAGS,
        sysstat_ru=SYSSTAT_RU,
        component_data=component_data
    )


@blueprint.route("/component_data/<component>", methods=["GET"])
def get_component_data(component):
    """
    Возвращает данные о компоненте в формате JSON.

    Параметры:
    component (str): Имя компонента.

    Возвращает:
    Response: JSON ответ с данными о компоненте.
    """
    data = read_yaml(component)
    return jsonify(data)


@blueprint.route("/start_services/<component>", methods=["GET"])
def start_services(component):
    """
    Запускает сервисы компонента.

    Параметры:
    component (str): Имя компонента.

    Возвращает:
    Response: JSON ответ с сообщением о запуске сервисов.
    """
    action = "запущены"
    minion_services_action_command(component, "start", "запущены")
    return jsonify({'message': f'{action} сервисы для компонента {component}'}), 200


@blueprint.route("/stop_services/<component>", methods=["GET"])
def stop_services(component):
    """
    Останавливает сервисы компонента.

    Параметры:
    component (str): Имя компонента.

    Возвращает:
    Response: JSON ответ с сообщением об остановке сервисов.
    """
    action = "остановлены"
    minion_services_action_command(component, "stop", action)
    return jsonify({'message': f'{action} сервисы для компонента {component}'}), 200


@blueprint.route("/restart_services/<component>", methods=["GET"])
def restart_services(component):
    """
    Перезапускает сервисы компонента.

    Параметры:
    component (str): Имя компонента.

    Возвращает:
    Response: JSON ответ с сообщением о перезапуске сервисов.
    """
    action = "перезапущены"
    minion_services_action_command(component, "restart", "перезапущены")
    return jsonify({'message': f'{action} сервисы для компонента {component}'}), 200

# service --status-all
