from apps.config import config
import yaml
import salt.client
from datetime import datetime

local = salt.client.LocalClient()

APP_PATH = config.get("APP_PATH")

def log_message(component, software_service_control, action):
    """
    Логирует сообщение о действии над сервисами компонента.

    Параметры:
    component (str): Имя компонента.
    software_service_control (list): Список сервисов, над которыми выполнено действие.
    action (str): Действие, выполненное над сервисами.
    """
    message = f'На компоненте {component} {action} сервисы {software_service_control}'

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')[:-3]
    log_entry = f'{timestamp} INFO: {message}\n'

    log_file_path = f'{APP_PATH}logs/minions/{component}.log'

    with open(log_file_path, 'a') as log_file:
        log_file.write(log_entry)


def execute_command(minion_id, command_to_execute):
    """
    Выполняет команду на указанном минионе.

    Параметры:
    minion_id (str): Идентификатор миниона.
    command_to_execute (str): Команда для выполнения.

    Возвращает:
    dict: Результат выполнения команды.
    """
    return local.cmd(minion_id, 'cmd.run', [command_to_execute])


def minion_services_action_command(component, action, log_action):
    """
    Выполняет действие над сервисами компонента и логирует это действие.

    Параметры:
    component (str): Имя компонента.
    action (str): Действие (start, stop, restart).
    log_action (str): Действие для логирования (запущен, перезапущен, остановлен).
    """
    with open(f'{APP_PATH}config.yaml', 'r', encoding='utf-8') as stream:
        config_full = yaml.safe_load(stream)
        service_list = config_full.get("components").get(component).get("software_service_control")
    command = ""
    is_container = config.get("LAUNCH_FROM_CONTAINER")
    for service in service_list:
        if is_container:
            command += f"service {service} {action} ;"
        else:
            command += f"systemctl {action} {service} ;"
    execute_command(component, command.rstrip(';'))
    log_message(component, service_list, log_action)


def read_last_lines(filepath, num_lines):
    """
    Читает последние строки из лог-файла.

    Параметры:
    filepath (str): Путь к лог-файлу.
    num_lines (int): Количество строк для чтения.

    Возвращает:
    list: Последние строки из файла.
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        return lines[-num_lines:]
    except Exception:
        return ['ожидание ответа']


def load_component_statuses():
    """
    Загружает статусы компонентов из YAML файла.

    Возвращает:
    dict: Статусы компонентов.
    """
    with open(f'{APP_PATH}modules/component_statuses.yaml', 'r', encoding='utf-8') as file:
        components = yaml.safe_load(file)
    return components


def read_yaml(minion):
    """
    Читает YAML файл и возвращает данные о компоненте.

    Параметры:
    minion (str): Имя миниона.

    Возвращает:
    dict: Данные о компоненте.
    """
    with open(f'{APP_PATH}modules/component_statuses.yaml', 'r', encoding='utf-8') as file:
        data = yaml.safe_load(file)
    data = {minion: data.get(minion)}
    print(data)

    log_length = config.get("COMPONENT_LOG_LENGTH")
    component_data = {}

    for component, statuses in data.items():
        component_data[component] = {}
        component_data[component]['sysstat_data'] = {}
        for test, status in statuses.items():
            if status == 'active' and test != 'component_service':
                component_data[component][test] = 'Онлайн'
            elif status == 'offline' and test != 'component_service':
                component_data[component][test] = 'Ошибка проверки'
            elif status == 'inactive' and test != 'component_service':
                component_data[component][test] = 'Внимание'
            elif test == 'component_service':
                component_data[component][test] = status
            else:
                component_data[component]['sysstat_data'][test] = status

        # component_data[component]['sysstat_data'] = {'disk_usage': 23, 'disk_usage_mb': 45612, 'getloadavg': 0.40, 'mem_available': int(50.564)}
        component_data[component]['log_data'] = read_last_lines(f'{APP_PATH}logs/minions/{minion}.log', log_length)

    return component_data
