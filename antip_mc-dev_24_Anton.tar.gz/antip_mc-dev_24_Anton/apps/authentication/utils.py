# -*- encoding: utf-8 -*-
import hashlib
import yaml
from flask_login import UserMixin
from apps.config import config


def hash_pass(password):
    """Возвращает хэш пароля."""
    salt = b'3901c5'
    return hashlib.sha256(salt + password.encode("utf-8")).hexdigest()


# def get_admin_password():
#     """Возвращает пароль администратора."""
#     with open('config.yaml', "r") as stream:
#         try:
#             load = yaml.safe_load(stream)
#             for i in load:
#                 if i == 'ADMIN_PASSWORD':
#                     return load[i]
#         except yaml.YAMLError as exc:
#             print("Ошибка чтения конфиг файла", exc)


def create_users():
    """Создает пользователей. Нужна для работы flask-login без БД."""
    data = {
        "1": {
            "username": config.get('ADMIN_USERNAME'),
            "password": config.get('ADMIN_PASSWORD')
        },
    }
    return {
        key: User(
             id=key,
             username=data[key]["username"],
             password=data[key]["password"],
         )
        for key in data
    }


class User(UserMixin):
    """Класс пользователя, для работы с flask-login.
       Метод get необходим для работы декоратора авторизации.
       Метод get_user_by_login используется для поиска пользователя по логину."""
    def __init__(self, id: str, username: str, password: str):
        self.id = id
        self.username = username
        self.password = password

    @staticmethod
    def get(user_id: str):
        return create_users().get(user_id)

    @staticmethod
    def get_user_by_login(user_login: str):
        users = create_users()
        for user in users:
            return users[user] if users[user].username == user_login else None

    def __str__(self) -> str:
        return f"<Id: {self.id}, Username: {self.username}>"

    def __repr__(self) -> str:
        return self.__str__()

