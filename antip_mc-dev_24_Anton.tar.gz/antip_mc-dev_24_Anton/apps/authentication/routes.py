from flask import current_app as app
from apps.authentication import blueprint
from apps.config import config
from flask import redirect, render_template, url_for, request, flash
from flask_login import (
    login_required,
    login_user,
    logout_user,
    current_user
)
from apps import login_manager
from . import forms
from . import utils


@login_manager.user_loader
def load_user(user_id: str):
    """Функция для логина пользователя."""
    return utils.User.get(user_id)


@blueprint.route("/")
@login_required
def route_default():
    """Залогиненных пользователей переадресует на домашную страницу,
       незалогиненных - на страницу авторизации."""
    return (redirect(url_for("home_blueprint.home")))


@blueprint.route("/login", methods=["GET", "POST"])
def login():
    """Страница авторизации."""
    form = forms.LoginForm()
    if request.method == "GET":
        if current_user.is_authenticated:
            return (redirect(url_for("home_blueprint.home")))
        return (render_template("auth/login.html", form=form))
    login = request.form.get('login')
    password = utils.hash_pass(request.form.get('password'))
    user = utils.User.get_user_by_login(login)
    if user and user.password == password:
        login_user(user)
        app.logger.info(f"Пользователь {login} успешно авторизовался.")
        return redirect(url_for("home_blueprint.home"))
    app.logger.warning(f"Неудачна попытка авторизации пользователя с логином: {login}")
    flash('Неверный пароль', 'warning')
    return redirect('/login')


@blueprint.route("/logout")
@login_required
def logout():
    """Завершение сессии пользователя."""
    app.logger.info(f"Пользователь {current_user.username} успешно завершил сессию.")
    logout_user()
    return redirect(url_for("authentication_blueprint.login"))


@blueprint.route("/_gen_password", methods=["GET", "POST"])
def _gen_password():
    """Генерирует и возвращает хэш нового пароля."""
    form = forms.ChangePasswordForm()
    if request.method == "GET":
        return render_template("auth/change_password.html", form=form)
    secret_key = request.form.get('secret_key')
    if secret_key != config.get('SECRET_KEY'):
        flash('Неверный секретный ключ', 'warning')
        return render_template("auth/change_password.html", form=form)
    new_password_hash = utils.hash_pass(request.form.get('new_password'))
    if new_password_hash == config.get('ADMIN_PASSWORD'):
        flash('Это текущий пароль', 'warning')
        return render_template("auth/change_password.html", form=form)
    app.logger.info("Сгененирован хэш для нового пароля.")
    return render_template("auth/new_password.html", new_password_hash=new_password_hash)



@login_manager.unauthorized_handler
def unauthorized_handler():
    """Функция для работы декоратора авторизации."""
    return (redirect(url_for("authentication_blueprint.login")))

