from flask_wtf import Form
from wtforms import StringField
from wtforms.validators import InputRequired

class LoginForm(Form):
    """Форма для введения пароля."""
    login = StringField('login', validators = [InputRequired()])
    password = StringField('password', validators = [InputRequired()])


class ChangePasswordForm(Form):
    """Форма для введения изменения пароля."""
    secret_key = StringField('secret_key', validators = [InputRequired()])
    new_password = StringField('new_password', validators = [InputRequired()])
