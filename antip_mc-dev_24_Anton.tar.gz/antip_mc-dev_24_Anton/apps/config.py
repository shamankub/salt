# -*- encoding: utf-8 -*-
from threading import Lock

import yaml


class ConfigClass(object):

    def __init__(self, filename):
        self._lock = Lock()
        self.filename = filename
        self.load = "abc"
        with open(self.filename, "r") as stream:
            try:
                self.load = yaml.safe_load(stream)
                for i in self.load:
                    setattr(self, i, self.load[i])
            except yaml.YAMLError as exc:
                print("Ошибка чтения конфиг файла", exc)

    def get(self, key, default=None):
        try:
            return self.__getitem__(key)
        except KeyError:
            return default

    def __getitem__(self, item):
        with self._lock:
            namespace = item.split(".")
            data = self.load
            for name in namespace:
                data = data[name]
            return data


class Config(ConfigClass):
    def __init__(self, filename):
        ConfigClass.__init__(self, filename)

        # Core API config
        self.CORE_API = f"{self.get('core.proto')}://{self.get('core.host')}:{self.get('core.port')}"

        # Security setup
        if not self.get("DEBUG"):
            self.SESSION_COOKIE_HTTPONLY = True
            self.REMEMBER_COOKIE_HTTPONLY = True
            self.REMEMBER_COOKIE_DURATION = 3600
            self.SESSION_PROTECTION = "strong"
            self.TEMPLATES_AUTO_RELOAD = False
        else:
            self.RMQ_INFO = f"amqp://{self.get('rmq.host')}:{self.get('rmq.port')}/{self.get('rmq.vhost')}"
            self.DB_INFO = f"{self.get('db.engine')}://{self.get('db.host')}:{self.get('db.port')}/{self.get('db.name')}"


# Load all possible configurations
config = Config("./config.yaml")
