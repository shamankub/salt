# -*- encoding: utf-8 -*-

# Словарь возможных тегов для разных групп тестов
TESTS_NAMES = {
    'postgresql': 'База данных',
    'rabbitmq-server': 'RabbitMQ',
    'network': 'Сеть',
    'sysstat': 'Система',
    'idm': 'SCIM',
}

# Словарь показателей системы
SYSSTAT_TAGS = {
    'disk_usage': 'Процент использования диска',
    'disk_usage_mb': 'Остаток места на диске',
    'getloadavg': 'Загрузка системы за 15 минут',
    'mem_available': 'Доступная память в процентах',
}

SYSSTAT_RU = {
    'disk_usage': 'Использовано (%)',
    'disk_usage_mb': 'Доступно (Мб)',
    'getloadavg': 'Средняя загрузка (%)',
    'mem_available': 'Доступно (%)',
}