import yaml
import salt.client
import json
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from apps.config import config


local = salt.client.LocalClient()
state_file = 'modules/component_state.json'
file_path = 'modules/component_statuses.yaml'


# def load_config(config_file_path):
#     """
#     Загружает конфигурацию из YAML файла и возвращает её в виде словаря.

#     Параметры:
#     config_file_path (str): Путь к YAML файлу конфигурации.

#     Возвращает:
#     dict: Конфигурация в виде словаря.
#     """
#     with open(config_file_path, 'r') as file:
#         config = yaml.safe_load(file)
#     return config


def execute_command(minion_id, command_to_execute):
    """
    Выполняет команду на указанном минионе.

    Параметры:
    minion_id (str): Идентификатор миниона.
    command_to_execute (str): Команда для выполнения.

    Возвращает:
    dict: Результат выполнения команды.
    """
    return local.cmd(minion_id, 'cmd.run', [command_to_execute])


def send_email(subject, body):
    """
    Отправляет email-сообщение с заданной темой и телом.

    Параметры:
    subject (str): Тема письма.
    body (str): Тело письма.

    Возвращает:
    bool: True, если письмо было успешно отправлено, иначе False.
    """
    # config = load_config('config.yaml')
    # sender_email = config.get("mail", {}).get("user")
    # smtp_server = config.get("mail", {}).get("server")
    # smtp_port = config.get("mail", {}).get("port")
    # use_tls = config.get("mail", {}).get("tls")
    # password = config.get("mail", {}).get("pass")
    # receivers = config.get("mail", {}).get("recipients")

    sender_email = config.get("mail.user")
    smtp_server = config.get("mail.server")
    smtp_port = config.get("mail.port")
    if smtp_port != 465:
        smtp_server = f"{smtp_server}:{smtp_port}"
    use_tls = config.get("mail.tls")
    password = config.get("mail.pass")
    receivers = config.get("mail.recipients")
    try:
        recipients = receivers.split(", ")

        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = ", ".join(recipients)
        message["Subject"] = subject

        message.attach(MIMEText(f"<p>{body}</p>", "html"))

        server = smtplib.SMTP(smtp_server)
        if use_tls:
            server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, recipients, message.as_string())
        server.quit()
        return True
    except Exception as e:
        error_message = f"[SMTP] Не удалось отправить email-сообщение. Код ошибки: {str(e)}"
        return False


def load_state():
    """
    Загружает состояние из файла.

    Возвращает:
    dict: Загруженное состояние.
    """
    try:
        with open(state_file, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}


def save_state(state):
    """
    Сохраняет состояние в файл.

    Параметры:
    state (dict): Состояние для сохранения.
    """
    with open(state_file, 'w') as file:
        json.dump(state, file, indent=4)


def transform_dict_to_yaml(output_filename):
    """
    Функция преобразует словарь в YAML файл. 
    Если значение словаря является строкой YAML, она добавляет его содержимое в выходной файл. 
    Если значение равно False, она добавляет запись с сервисами в состоянии offline.
    
    Параметры:
    output_filename (str): Имя файла, в который будет записан преобразованный YAML.
    
    Возвращает:
    None
    """
    input_dict = execute_command("*", "cat /tmp/output.yaml")
    new_data = {}
    
    # Повторный запрос для неответивших миньонов
    retry_minions = [key for key, value in input_dict.items() if value is False]
    if retry_minions:
        retry_results = execute_command(','.join(retry_minions), "cat /tmp/output.yaml")
        input_dict.update(retry_results)

    for key, value in input_dict.items():
        if key == "local_minion":
            continue
        elif value and value != "cat: /tmp/output.yaml: No such file or directory":
            # Парсим YAML строку и добавляем её в новый словарь
            parsed_value = yaml.safe_load(value)
            new_data.update(parsed_value)
        else:
            # Добавляем запись с сервисами в состоянии offline
            new_data[key] = {
                "component_service": "offline",
                "disk_usage": 0,
                "disk_usage_mb": 0,
                "getloadavg": 0.0,
                "mem_available": 0,
                "network": "offline",
                "postgresql": "offline",
                "sysstat": "offline",
                "rabbitmq-server": "offline"
            }

    with open(output_filename, 'w', encoding='utf-8') as file:
        yaml.dump(new_data, file, allow_unicode=True)

    return(new_data)


def check_and_notify(data):
    """
    Функция проверяет статусы компонентов и отправляет уведомления, если компонент не прошел тест в течение трех минут.
    
    Параметры:
    data (dict): Данные YAML файла с описанием статусов компонентов.
    
    Возвращает:
    None
    """
    current_time = time.time()
    state = load_state()
    issues_to_notify = []
    resolved_issues = []
    all_issues = []
    # config = load_config('config.yaml')
    # notice_lag = config.get("mail", {}).get("notice_lag") * 60
    notice_lag = config.get("mail.notice_lag") * 60

    for component, statuses in data.items():
        issues = []
        if statuses.get('network', 'active') in ['offline', 'inactive']:
            issues.append("network")
        if statuses.get('postgresql', 'active') in ['offline', 'inactive']:
            issues.append("postgresql")
        if statuses.get('sysstat', 'active') in ['offline', 'inactive']:
            issues.append("sysstat")
        if statuses.get('rabbitmq-server', 'active') in ['offline', 'inactive']:
            issues.append("rabbitmq-server")
        
        if issues:
            if component not in state:
                state[component] = {}
            for issue in issues:
                status = "тест не пройден" if statuses[issue] == "inactive" else "ошибка проверки"
                all_issues.append(f"{component}: {issue} - {status}")
                if issue not in state[component]:
                    state[component][issue] = current_time
                elif current_time - state[component][issue] >= notice_lag:
                    issues_to_notify.append(f"{component}: {issue} - {status}")
                    state[component][issue] = 10 ** 10  # Обновляем время, чтобы не отправлять email слишком часто
        else:
            if component in state:
                resolved_issues.append(f"{component} - работоспособность полностью восстановлена")
                del state[component]  # Удаляем компонент из состояния, если все проверки пройдены

    save_state(state)

    current_issues = f"<br><br><b>Текущие проблемы:</b><br> {'<br>'.join(all_issues)}" if all_issues else "<br><br><b>Текущие проблемы отсутствуют</b><br>"
    if issues_to_notify:
        send_email(
            "Антифишинг МЦ: обнаружены проблемы",
            f"<b>Были обнаружены следующие проблемы:</b><br> {'<br>'.join(issues_to_notify)} {current_issues}"
        )

    if resolved_issues:
        send_email(
            "Антифишинг МЦ: решены проблемы",
            f"<b>Были решены следующие проблемы:</b><br> {'<br>'.join(resolved_issues)} {current_issues}"
        )


new_data = transform_dict_to_yaml(file_path)
check_and_notify(new_data)
