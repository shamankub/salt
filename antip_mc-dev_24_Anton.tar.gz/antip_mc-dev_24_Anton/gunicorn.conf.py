# -*- encoding: utf-8 -*-

"""gunicorn config file"""

import os

bind = ["0.0.0.0:5090", "unix:AntiP_mc.sock"]
workers = 1
threads = 100

enable_stdio_inheritance = True
limit_request_line = 0
timeout = 90

umask = 0o007
preload = True

# certfile = "nginx-selfsigned.crt"
# keyfile = "nginx-selfsigned.key"

if not os.path.exists("logs"):
    os.mkdir("logs")

logconfig = "log.conf"
