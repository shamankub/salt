#!/bin/bash

PROJECT_PATH="/opt/AntiP_mc"
VENV_PATH="/opt/AntiP_mc/venv"

source "$VENV_PATH/bin/activate"
cd "$PROJECT_PATH"

export PYTHONPATH="$PROJECT_PATH"

python modules/collect_test_results.py
