#!/bin/bash

config_file="/opt/AntiP_mc/config.yaml"
logs_dir="/opt/AntiP_mc/logs/minions"

log_length=$(yq '.COMPONENT_LOG_LENGTH' $config_file)
# echo "Длина лога в конфиге $log_length"

# Создаем список файлов с расширением *.log
logs_array=()
while IFS= read -r -d '' file; do
    logs_array+=("$file")
done < <(find "$logs_dir" -type f -name "*.log" -print0)

for log_file in ${logs_array[@]}; do
  # Проверяем, существует ли файл
  if [[ -f $log_file ]]; then
    # Сохраняем последние n строк файла
    tail -n "$log_length" "$log_file" > "$log_file.tmp"
    mv -f "$log_file.tmp" "$log_file"
  fi
done
