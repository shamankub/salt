from apps import create_app, socketio
from apps.config import config
# from apps.home.socket_events import start_sockets


app = create_app(config)
# start_sockets()

try:
    with open("VERSION", "r") as f:
        app.jinja_env.globals["version"] = f.read()
finally:
    f.close()


if __name__ == "__main__":
    socketio.run(app, host=app.config["HOST"], port=app.config["PORT"], ssl_context=app.config["SSL"])

